/*
Programmer:  Joseph Falco
Program Name:  Animal
Date: 2/19/2023
Purpose: The purpose of animal class is to create an object that describes an animal. 
*/

public class Animal{
   
   public String color;
   public String furType;
   
   
   public Animal(){
      
      this.color = "Brown";
      furType = "Fur";
   
   }
   
   public Animal(Animal object2){
      
      color = object2.color;
      furType = object2.furType;
   
   }
   
   public Animal(String color, String fur){
      
      this.color = color;
      furType = fur;
   
   }
   
   public void setColor(String color){
      
      this.color = color;
   
   }
   
   public void setFur(String fur){
      
      furType = fur;
   
   }
   
   public String getColor(){
      
      return color;
   
   }
   
   public String getFur(){
      
      return furType;
   
   }
   
   public String toString(){
      
      String str = "The animal is " + color + " with " + furType + " Fur";
      return str;
   
   }
   
   public boolean equals(Animal object2){
   
      boolean status;
      
      if(color.equals(object2.color) && furType.equals(object2.furType))
         status = true;
      else
         status = false;
      return status;
   
   }

}   