/*
Programmer:  Joseph Falco
Program Name:  AnimalCreation
Date: 2/19/2023
Purpose: The purpose of AnimalCreation is to test the animal, cat, and dog classes. 
*/

import java.util.Scanner;
import java.util.ArrayList;

public class AnimalCreation {
   
   public static void main(String[] args) {
   
      String animal;
      String color, fur;
      String breed, age;
      String size, lives;
      int animals;
   
      Scanner keyboard = new Scanner(System.in);
      
      System.out.println("How many animals would you like to create? ");
      animals = keyboard.nextInt();
      keyboard.nextLine();
      
      Animal[] myAnimal = new Animal[animals];
      
      for(int i = 0; i < animals; i++){
           
         //prompt user to select animal type
         System.out.println("Select Dog or Cat");
         animal = keyboard.nextLine();
         animal = animal.toUpperCase();
         
         //if dog prompt user to input color, fur, breed, and age
         if(animal.equals("DOG")) {
            
            System.out.println("Color ");
            color = keyboard.nextLine();
            System.out.println("Fur Type ");
            fur = keyboard.nextLine();
            System.out.println("Breed ");
            breed = keyboard.nextLine();
            System.out.println("Age ");
            age = keyboard.nextLine();
            
            try
            {
               myAnimal[i] = new Dog(color, fur, breed, age);
            }
            catch(NegativeDog e)
            {
               System.out.println(e.getMessage());
            }
         }
          
         //if cat prompt user to input color, fur, size, and lives
         if(animal.equals("CAT")) {
            
            System.out.println("Color ");
            color = keyboard.nextLine();
            System.out.println("Fur Type ");
            fur = keyboard.nextLine();
            System.out.println("Size ");
            size = keyboard.nextLine();
            System.out.println("Lives ");
            lives = keyboard.nextLine();
            
            try
            {
               myAnimal[i] = new Cat(color, fur, size, lives);
            }
            catch(NegativeLives e)
            {
               System.out.println(e.getMessage());
            }
            catch(TooManyLives e)
            {
               System.out.println(e.getMessage());
            }
         }
         
      }
      
      for(int i = 0; i < myAnimal.length; i++){
         
         if(myAnimal[i] instanceof Dog)
            System.out.println("\n" + ((Dog) myAnimal[i]).dogString());
         if(myAnimal[i] instanceof Cat)
            System.out.println("\n" + ((Cat) myAnimal[i]).catString());
       
      }

   }

}
         
         
      
      
      