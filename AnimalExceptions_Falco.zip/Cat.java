/*
Programmer:  Joseph Falco
Program Name:  Cat
Date: 2/19/2023
Purpose: The purpose of cat class is to create an object that describes a cat. 
*/

public class Cat extends Animal{
   
   public String size;
   public String lives;
   
   public Cat(){
      
      super();
      size = "Large";
      lives = "9";
   
   }
   
   public Cat(String color, String fur, String size, String lives) throws NegativeLives, TooManyLives{
      
      super(color, fur);
      
      if(Integer.parseInt(lives) < 0)
         throw new NegativeLives(Integer.parseInt(lives));
      if(Integer.parseInt(lives) > 9)
         throw new TooManyLives(Integer.parseInt(lives));
      
      this.size = size;
      this.lives = lives;
   
   }
   
   public Cat(Cat object2){
      
      super(object2.color, object2.furType);
      
      size = object2.size;
      lives = object2.lives;
   
   }
   
   public void setSize(String a){
      size = a;
   }
   
   public void setLives(String b){
      lives = b;
   }
   public String getSize(){
      return size;
   }
   public String getLies(){
      return lives;
   }

   
   public String catString(){
      
      String str = toString() + "\nSize of Cat " + size + " Lives remaining " + lives;
      return str;
      
   }
   
}
