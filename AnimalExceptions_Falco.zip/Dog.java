/*
Programmer:  Joseph Falco
Program Name:  Dog
Date: 2/19/2023
Purpose: The purpose of dog class is to create an object that describes a dog. 
*/

public class Dog extends Animal{
   
   public String breed;
   public String age;
   
   public Dog(){
      
      super();
      breed = "Poodle";
      age = "2";
   
   }
   
   public Dog(String color, String fur, String breed, String age) throws NegativeDog
   {
      
      super(color, fur);
      
      if(Integer.parseInt(age) < 0)
         throw new NegativeDog(Integer.parseInt(age));
      
      this.breed = breed;
      this.age = age;
   
   }
   
   public Dog(Dog object2){
      
      super(object2.color, object2.furType);
      
      breed = object2.breed;
      age = object2.age;
   
   }
   
   public void setAge(String a){
      age = a;
   }
   
   public void setBreed(String b){
      breed = b;
   }
   public String getAge(){
      return age;
   }
   public String getBreed(){
      return breed;
   }
   
   public int dogYears(){
      
      int years = Integer.parseInt(age) * 7;
      return years;
   
   }
   
   public String dogString(){
      
      String str = toString() + "\nDog Breed " + breed + " Age in Dog Years " + dogYears();
      return str;
      
   }
   
}
      