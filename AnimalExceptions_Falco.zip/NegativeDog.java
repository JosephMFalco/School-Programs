/*
Programmer:  Joseph Falco
Program Name: NegativeDog
Date: 2/26/2023
Purpose: The purpose of NegativeDog is to throw exceptions when the age parameter of the dog class is negative 
*/

public class NegativeDog extends Exception{
   
   public NegativeDog(){
      
      super("Error: Dog Years Cannot Be Negative");
      
   }
   
   public NegativeDog(int age){
      
      super("Error: Negative Dog Years: " + age);
      
   }
   
}