/*
Programmer:  Joseph Falco
Program Name: NegativeLives
Date: 2/26/2023
Purpose: The purpose of Negativelives is to throw exceptions when the lives parameter of the cat class is negative 
*/

public class NegativeLives extends Exception{
   
   public NegativeLives(){
      
      super("Error: Cats Cannot Have Negative Lives");
      
   }
   
   public NegativeLives(int lives){
      
      super("Error: Cats Cannot Have " + lives + " lives");
      
   }

}