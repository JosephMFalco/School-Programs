/*
Programmer:  Joseph Falco
Program Name: TooManyLives
Date: 2/26/2023
Purpose: The purpose of TooManyLives is to throw exceptions when the lives parameter of the cat class exceeds 9 
*/

public class TooManyLives extends Exception{
   
   public TooManyLives(){
      
      super("Error: Cats Only Have 9 Lives");
   
   }
   
   public TooManyLives(int lives){
      
      super("Error: Cats only have 9 Lives not " + lives);
   
   }
   
}