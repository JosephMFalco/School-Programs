/**Programmer:  Joseph Falco
Program Name:  Numbers_Spaces_Subtrings
Date: 2/1/2023
Purpose: Reads a user input as a string and displays # of digits, spaces, and substrings. Also displays all substrings and can search for specific substrings.
Met Specifications: yes*/



import java.util.ArrayList;
import java.util.Scanner;

public class Numbers_Spaces_Subtrings
{
   public static void main(String[] args)
   {
      
      String str = "", search = " ";
      int choice = 0;
      
      Scanner keyboard = new Scanner(System.in);
      
      System.out.println("Enter a string of digits");
      str = keyboard.nextLine();
      
      //create Substrings object
      Substrings mySub = new Substrings(str);
      ArrayList<String> list = mySub.getSubStrings();
      
      //create while loop so user can choose multiple options
      while(choice != 6)
      {
         
         System.out.println("\n____________________________________________________________________________________" 
                           +"\n1)# of Digits 2)# of Spaces 3)# of Substrings 4)Search 5)Print All Substrings 6)Exit");
         choice = keyboard.nextInt();
         keyboard.nextLine();
         
         //select resepctive output based off user selection
         if(choice == 1)
            System.out.println(mySub.numberOfDigits() + " Digits");
         if(choice == 2)
            System.out.println(mySub.numberOfSpaces() + " Spaces");
         if(choice == 3)
            System.out.println(list.size() + " SubStrings");
         if(choice == 4){
            System.out.println("Enter SubString for search");
            search = keyboard.nextLine();
            //create advance for loop to cycle through array list to search for specific substring
            for(String var : list){
               if(var.startsWith(search))
                  System.out.println(var);
            }
         }
         if(choice == 5)
            //create advance for loop to cycle through list and print each string
            for(String var : list)
               System.out.print(var + " ");
         if(choice == 6)
            System.out.println("Bye Bye");
      
      }
   }
}
            