/**Programmer:  Joseph Falco
Program Name:  Substrings
Date: 2/1/2023
Purpose: Accepts a string value and determines substrings that are seperated by spaces. 
Met Specifications: yes*/

import java.util.ArrayList;
public class Substrings extends WhatChar{
   
   public String str;
   
   public Substrings(String s){
      super(s);
      str = s;
   }
   
   public void setStr(String s){
      str = s;
   }
   
   public String getStr(){
      return str;
   }
   
   /*add each substring to an array list
   @return arraylist filled with substrings
   */
   public ArrayList<String> getSubStrings(){
      
      String subString = "";
      ArrayList<String> list = new ArrayList();
      
      //Create for loop to cycle through string 
      for(int i = 0; i < str.length(); i++){
         
         //assemble substring from string if character is a digit
         if(Character.isDigit(str.charAt(i)))
            subString += str.charAt(i);
         
         //add substring to list and erase substrings value if character is space
         if(Character.isSpace(str.charAt(i))){
            
            list.add(subString);
            subString = "";
         }
      
      }
      //add final substring 
      list.add(subString);
      
      return list;
      
   }
            
}