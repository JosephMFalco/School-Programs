/**Programmer:  Joseph Falco
Program Name:  WhatChar
Date: 2/1/2023
Purpose: Accepts a string and returns the total number of digits and spaces the string contained.
Met Specifications: yes*/

public class WhatChar{
   
   public String str;
      
   public WhatChar(String s){
      str = s;
   }
   
   public void setStr(String s){
      str = s;
   }
   
   public String getStr(){
      return str;
   }
   
   /*Find how many digits are contained in a string
   @return total number of digits contained in string
   */
   public int numberOfDigits(){
      
      int digits = 0;
      
      //create for loop to cycle through string and incrementing digits if character is a digit
      for(int i = 0; i < str.length(); i++)
      {
         
         if(Character.isDigit(str.charAt(i)))
            digits++;
      
      }
      
      return digits;
   }
   /*Find how many spaces are contained in a string
   @return total number of spaces contained in string
   */
   public int numberOfSpaces(){
      
      int spaces = 0;
      
      //create for loop to cycle through string and incrementing spaces if character is a space
      for(int i = 0; i < str.length(); i++)
      {
         
         if(Character.isSpace(str.charAt(i)))
            spaces++;
      
      }
      
      return spaces;
   }
   
}




      
      