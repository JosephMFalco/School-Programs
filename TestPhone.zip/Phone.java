/*
Programmer:  Joseph Falco
Program Name:  Phone
Date: 2/1/2023
Purpose: The purpose of Phone is to learn how to create the toString method, equals method, and a deep copy constructor.
*/

public class Phone{
   
   private String color;
   private String model;
   private String brand;
   
   public Phone(){
   
      color = "NA";
      model = "NA";
      brand = "NA";
   
   }
   
   public Phone(String col, String mod, String bran){
   
      color = col;
      model = mod;
      brand = bran;
   
   }
   
   public Phone(Phone object2){
   
      color = object2.color;
      model = object2.model;
      brand = object2.brand;   
      
   }
   
   public void setColor(String col){
   
      color = col;   
   
   }
   
   public void setModel(String mod){
   
      model = mod;
   
   }
      
   public void setBrand(String bran){
   
      brand = bran;
   
   }
      
   public String getColor(){
   
      return color;
   
   }
     
   public String getModel(){
   
      return model;
   
   }
      
   public String getBrand(){
   
      return brand;
   
   }

   public String toString(){
   
      String str = "Color: " + color + " Modle: " + model + " Brand: " + brand;
      return str;
   
   }
   
   public boolean equals(Phone object2){
   
      boolean status;
      
      if(color.equals(object2.color) && model.equals(object2.model) && brand.equals(object2.brand))
         status = true;
      else
         status = false;
      return status;
   
   }     

}