
public class NegativeScores extends Exception {

   public NegativeScores() {
      
      super("Cannot have negative scores");
      
   }
   
   public NegativeScores(String[] list) {
      
      super("Cannot have negative scores");
      
   }
   
}