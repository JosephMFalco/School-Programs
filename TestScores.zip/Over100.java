public class Over100 extends Exception {

   public Over100() {
      
      super("Cannot have a score larger than 100");
      
   }
   
   public Over100(String[] list) {
      
      super("Cannot have a score larger than 100");
      
   }
   
}