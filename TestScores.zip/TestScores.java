

public class TestScores {
   
   private String[] scores;
   
   public TestScores() {
      
      String[] list = new String[2];
      scores = list ;
   
   }
   
   public TestScores(String[] list) throws NegativeScores, Over100 { 
      
      for(String var : list){
         
         if(Double.parseDouble(var) < 0)
            throw new NegativeScores(list);
         if(Double.parseDouble(var) > 0)
            throw new Over100(list);
      }
      
      scores = list;
   
   }
   
   public double getAverage() {
      
      double sum = 0.0;
      double average;
      
      for(int i = 0; i < scores.length; i++) {
         
         sum += Double.parseDouble(scores[i]);
      
      }
      
      average = sum/scores.length;
      return average;
   
   }

}
      