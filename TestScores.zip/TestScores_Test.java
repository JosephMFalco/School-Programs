import java.util.Scanner;
import java.util.ArrayList;

public class TestScores_Test {
   
   public static void main(String[] args) {
      
      String grades = "";
      Double grade;
   
      Scanner keyboard = new Scanner(System.in);
    
      System.out.println("Input grades with spaces between");
      grades = keyboard.nextLine();
      
      
      String[] scores = grades.split(" "); 
      
      
      try {
         TestScores myTest = new TestScores(scores);
         System.out.println(myTest.getAverage());
      }
      catch(NegativeScores e) {
         System.out.println(e.getMessage());
      }
      catch(Over100 e) {
         System.out.println(e.getMessage());
      }
      
         
         
      
   }
   
}
      
      
      
      
      
      
   
   