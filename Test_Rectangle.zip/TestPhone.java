/*
Programmer:  Joseph Falco
Program Name:  TestPhone
Date: 2/1/2023
Purpose: The purpose of TestPhone is to test the Phone class's toString method, equals method, and the copy constructor. 
*/

import java.util.Scanner;

public class TestPhone  {
   public static void main(String[] args) {
      
      String color, brand, model;
  
      //create scanner object to read input
      Scanner keyboard = new Scanner(System.in);
      
      //create array that holds three phone objects 
      Phone[] phone = new Phone[3];
      
      //create for loop to iterate through phone object array and assign string values.
      for(int i = 1, x = 0; i < phone.length; i++)  {
         
         System.out.println("Color: ");
         color = keyboard.nextLine();
         System.out.println("Model: ");
         model = keyboard.nextLine(); 
         System.out.println("Brand: ");
         brand = keyboard.nextLine();           
         
         //assign phone object to array
         phone[x] = new Phone(color, model, brand);
         x++;
      }
      
      //check to see if phone objects are equal
      if(phone[0].equals(phone[1]))
         System.out.println("Phones 1 and 2 are the same.");
      else  
         System.out.println("Phones 1 and 2 are different.");
      
      //create copy of phone object 1
      phone[2] = new Phone(phone[0]);
      
      //create for loop to iterate through each phone object and print each toString method from the object
      for(int i = 0; i < phone.length; i++)    
         System.out.println("Phone " + i + ": " + phone[i].toString());
     
   }

}