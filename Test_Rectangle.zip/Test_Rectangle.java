  import java.util.Scanner;
  
  public class Test_Rectangle
  {
      public static void main(String[] args)
      {
         
         double width, length;
         
         //create array to store rectangle objects 
         Rectangle[] rectangles = new Rectangle[3];  
        
         for(int i = 0; i < rectangles.length; i++)
         {
         
            //create scanner object to read input
            Scanner keyboard = new Scanner(System.in);
            
            //create do while loop to force user to enter a value greater than 0
            do
            {
              
               System.out.println("width: ");
               width = keyboard.nextDouble();
               
            }
            while(width <= 0);
            
            //create do while loop to force user to enter a value greater than 0
            do
            {
               
               System.out.println("length: ");
               length = keyboard.nextDouble();
            
            }
            while(length <= 0);
            
            //create new rectangle object
            rectangles[i] = new Rectangle(length,width);     
         
         }
         
         //create counter to indicate which rectangle is referenced
         int i = 1;
         
         //create enhanced for loop to print each rectangles information
         for(Rectangle var : rectangles)
         {
            
            System.out.print("Rectangle " + i + "- " + "Length: " + var.getLength() + "   Width: " + var.getWidth() + "   Area: " + var.getArea());
            
            i++;
            System.out.println(" ");
            
         }
      
      }
   
   }